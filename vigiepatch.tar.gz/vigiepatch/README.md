# VigiePatch

Dashboard d'équipe pour suivre CVE et mises à jour du parc : prise en compte, statuts, notes, notifications.

## Installation (Debian 12, en root)

    ./deploy/install.sh

Le script crée l'utilisateur système, le venv, `/etc/vigiepatch.env` (mot de passe initial de l'administrateur généré), le service
`vigiepatch` (port 8080) et un timer qui collecte toutes les heures.

## Comptes et rôles

Le premier démarrage crée l'administrateur `VIGIEPATCH_ADMIN_EMAIL` (par défaut walid@gmail.com) avec
`VIGIEPATCH_PASSWORD`. Ensuite, le bouton **Utilisateurs** (administrateur) permet d'ajouter des comptes par
adresse email, de changer leur rôle, de réinitialiser un mot de passe, de désactiver ou supprimer un compte.

| Rôle | Droits |
|---|---|
| Administrateur | tout, dont utilisateurs et parc |
| Technicien | prendre en compte, changer le statut, noter |
| Consultation | lecture seule |

Un compte sans mot de passe se connecte uniquement via Microsoft. Il reste toujours au moins un administrateur actif.

## SSO Microsoft Entra

1. Entra ID > Inscriptions d'applications > Nouvelle inscription, un seul locataire.
2. URI de redirection (type Web) : `https://vigiepatch.exemple.fr/auth/entra/callback`
3. Certificats et secrets : crée un secret client.
4. Renseigne dans `/etc/vigiepatch.env` : `VIGIEPATCH_PUBLIC_URL`, `ENTRA_TENANT_ID` (GUID du locataire),
   `ENTRA_CLIENT_ID`, `ENTRA_CLIENT_SECRET`, puis `systemctl restart vigiepatch`.
5. Le bouton « Se connecter avec Microsoft » apparaît. Le compte doit exister dans VigiePatch (même email), ou
   `ENTRA_AUTO_CREATE_ROLE=consultation` crée les comptes inconnus de ton locataire à la première connexion.
6. Pour imposer le SSO : `VIGIEPATCH_LOCAL_AUTH=false` (après avoir vérifié qu'un administrateur peut se connecter).

## Parc

Un administrateur ajoute des produits depuis le dashboard (« + Ajouter au parc »), ou édite `/var/lib/vigiepatch/inventory.json`.
Un produit peut avoir un `cpe` (précis) ou un `keyword` (large). Vérifie les CPE : un CPE trop large génère du bruit.

## Notifications

`VIGIEPATCH_WEBHOOK` reçoit un message à chaque nouvelle CVE critique (CVSS 9+) ou exploitée (CISA KEV).
Slack/Teams/Mattermost : format `json`. ntfy : `VIGIEPATCH_WEBHOOK_FORMAT=text`.

## HTTPS

Le mot de passe passe en clair sans HTTPS. Derrière Caddy, par exemple :

    vigiepatch.exemple.fr { reverse_proxy 127.0.0.1:8080 }

Puis dans `vigiepatch.service`, remplace `--host 0.0.0.0` par `--host 127.0.0.1`.

## Utile

    systemctl start vigiepatch-collect      # collecte immédiate
    journalctl -u vigiepatch-collect -f     # suivre la collecte
    sqlite3 /var/lib/vigiepatch/vigiepatch.db  # sauvegarde : copier ce fichier
