#!/usr/bin/env bash
# Installation de VigiePatch sur Debian 12 (en root) : ./deploy/install.sh
set -euo pipefail

[ "$(id -u)" -eq 0 ] || { echo "Lance ce script en root."; exit 1; }
SRC="$(cd "$(dirname "$0")/.." && pwd)"
DEST=/opt/vigiepatch
ENVF=/etc/vigiepatch.env

apt-get update -qq
apt-get install -y -qq python3 python3-venv rsync

id vigiepatch >/dev/null 2>&1 || useradd --system --home "$DEST" --shell /usr/sbin/nologin vigiepatch
mkdir -p "$DEST" /var/lib/vigiepatch
rsync -a --delete --exclude data --exclude .venv --exclude __pycache__ --exclude deploy "$SRC"/ "$DEST"/
python3 -m venv "$DEST/.venv"
"$DEST/.venv/bin/pip" install -q --upgrade pip
"$DEST/.venv/bin/pip" install -q -r "$DEST/requirements.txt"

# Inventaire initial (jamais écrasé s'il existe déjà)
[ -f /var/lib/vigiepatch/inventory.json ] || cp "$SRC/inventory.json" /var/lib/vigiepatch/inventory.json
chown -R vigiepatch:vigiepatch /var/lib/vigiepatch "$DEST"

if [ ! -f "$ENVF" ]; then
  PW="$(python3 -c 'import secrets; print(secrets.token_urlsafe(18))')"
  cat > "$ENVF" <<EOF
VIGIEPATCH_DATA=/var/lib/vigiepatch
# Premier administrateur (créé au premier démarrage) et son mot de passe initial
VIGIEPATCH_ADMIN_EMAIL=walid@gmail.com
VIGIEPATCH_PASSWORD=$PW
# URL publique (obligatoire pour le SSO Entra), ex. https://vigiepatch.exemple.fr
VIGIEPATCH_PUBLIC_URL=
# false = désactive la connexion par mot de passe (à n'activer qu'une fois le SSO validé)
VIGIEPATCH_LOCAL_AUTH=true
# SSO Microsoft Entra (laisser vide pour désactiver)
ENTRA_TENANT_ID=
ENTRA_CLIENT_ID=
ENTRA_CLIENT_SECRET=
# Rôle donné aux comptes Entra inconnus à leur première connexion (vide = refuser, sinon admin, technicien ou consultation)
ENTRA_AUTO_CREATE_ROLE=
# Clé NVD gratuite (https://nvd.nist.gov/developers/request-an-api-key) : collecte beaucoup plus rapide
NVD_API_KEY=
# Notifications : URL Slack/Teams/Mattermost (json) ou ntfy (text)
VIGIEPATCH_WEBHOOK=
VIGIEPATCH_WEBHOOK_FORMAT=json
EOF
  chmod 640 "$ENVF"; chown root:vigiepatch "$ENVF"
  echo "Administrateur : walid@gmail.com, mot de passe initial : $PW  (voir $ENVF)"
fi

install -m 644 "$SRC"/deploy/vigiepatch.service /etc/systemd/system/vigiepatch.service
install -m 644 "$SRC"/deploy/vigiepatch-collect.service /etc/systemd/system/vigiepatch-collect.service
install -m 644 "$SRC"/deploy/vigiepatch-collect.timer /etc/systemd/system/vigiepatch-collect.timer
systemctl daemon-reload
systemctl enable --now vigiepatch.service vigiepatch-collect.timer
systemctl start vigiepatch-collect.service --no-block || true

echo
echo "VigiePatch écoute sur http://<ip-du-serveur>:8080 (connexion : walid@gmail.com et le mot de passe ci-dessus)."
echo "Mets-le derrière HTTPS (voir README) avant tout accès hors réseau interne."
echo "Suivi de la première collecte : journalctl -u vigiepatch-collect -f"
