import hashlib
import json
import os
import re
import secrets
import sqlite3
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from pydantic import BaseModel, Field

from . import auth, db

STATIC = Path(__file__).parent / "static"
COOKIE = "vp_session"
OIDC_COOKIE = "vp_oidc"
LOCAL_AUTH = os.environ.get("VIGIEPATCH_LOCAL_AUTH", "true").lower() != "false"


@asynccontextmanager
async def lifespan(_):
    auth.ensure_admin()
    yield


app = FastAPI(title="VigiePatch", docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)


# ---------- dépendances ----------
def user_or_none(request: Request):
    data = auth.unsign(request.cookies.get(COOKIE, ""))
    if not data or "e" not in data:
        return None
    with db.connect() as con:
        u = auth.get_user(con, data["e"])
    return dict(u) if u and u["active"] else None


def need(*roles):
    def dep(u=Depends(user_or_none)):
        if u is None:
            raise HTTPException(401, "Session expirée, reconnecte-toi")
        if roles and u["role"] not in roles:
            raise HTTPException(403, "Ton rôle ne permet pas cette action")
        return u
    return dep


any_user = need()
can_write = need("admin", "technicien")
admin_only = need("admin")


def start_session(resp, request, email):
    with db.connect() as con:
        con.execute("UPDATE users SET last_login=? WHERE email=?", (db.now(), email))
    resp.set_cookie(COOKIE, auth.sign({"e": email}, auth.SESSION_TTL), max_age=auth.SESSION_TTL,
                    httponly=True, samesite="lax", secure=request.url.scheme == "https", path="/")


def public_url(request: Request) -> str:
    return os.environ.get("VIGIEPATCH_PUBLIC_URL", "").rstrip("/") or str(request.base_url).rstrip("/")


# ---------- modèles ----------
class LoginIn(BaseModel):
    email: str
    password: str


class StatusIn(BaseModel):
    status: str


class NoteIn(BaseModel):
    text: str = Field(min_length=1, max_length=2000)


class ProductIn(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    ver: str = Field(min_length=1, max_length=30)
    n: int = Field(1, ge=0, le=9999)


class UserIn(BaseModel):
    email: str
    name: Optional[str] = Field(None, max_length=60)
    role: str = "consultation"
    password: Optional[str] = None


class UserPatch(BaseModel):
    name: Optional[str] = Field(None, max_length=60)
    role: Optional[str] = None
    active: Optional[bool] = None
    password: Optional[str] = None


# ---------- pages ----------
@app.get("/")
def index(u=Depends(user_or_none)):
    return FileResponse(STATIC / "index.html") if u else RedirectResponse("/login")


@app.get("/login")
def login_page():
    return FileResponse(STATIC / "login.html")


# ---------- authentification ----------
@app.get("/api/auth/config")
def auth_config():
    return {"local": LOCAL_AUTH, "entra": auth.entra_conf() is not None}


@app.post("/api/login")
def login(body: LoginIn, request: Request):
    if not LOCAL_AUTH:
        raise HTTPException(403, "La connexion par mot de passe est désactivée, utilise Microsoft")
    email = auth.norm_email(body.email)
    key = f"{request.client.host if request.client else '-'}|{email}"
    if auth.throttled(key):
        raise HTTPException(429, "Trop de tentatives, réessaie dans quelques minutes")
    with db.connect() as con:
        u = auth.get_user(con, email)
    if not (u and u["active"] and auth.verify_password(body.password, u["pw_hash"])):
        auth.record_fail(key)
        raise HTTPException(401, "Email ou mot de passe incorrect")
    auth.clear_fail(key)
    resp = JSONResponse({"ok": True})
    start_session(resp, request, email)
    return resp


@app.post("/api/logout")
def logout():
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(COOKIE, path="/")
    return resp


@app.get("/auth/entra/login")
def entra_login(request: Request):
    conf = auth.entra_conf()
    if not conf:
        raise HTTPException(404, "SSO Entra non configuré")
    state, nonce, verifier = (secrets.token_urlsafe(24) for _ in range(3))
    challenge = auth.b64(hashlib.sha256(verifier.encode()).digest())
    url = auth.entra_authorize_url(conf, public_url(request) + "/auth/entra/callback", state, nonce, challenge)
    resp = RedirectResponse(url)
    resp.set_cookie(OIDC_COOKIE, auth.sign({"s": state, "n": nonce, "v": verifier}, 600), max_age=600,
                    httponly=True, samesite="lax", secure=request.url.scheme == "https", path="/auth/entra")
    return resp


@app.get("/auth/entra/callback")
def entra_callback(request: Request, code: str = "", state: str = "", error: str = ""):
    def fail(msg):
        return RedirectResponse("/login?err=" + msg.replace(" ", "+"))

    conf = auth.entra_conf()
    flow = auth.unsign(request.cookies.get(OIDC_COOKIE, ""))
    if not conf or not flow:
        return fail("Connexion Microsoft expirée, recommence")
    if error or not code:
        return fail("Connexion Microsoft refusée")
    if not secrets.compare_digest(state, flow["s"]):
        return fail("Réponse Microsoft invalide (state)")
    try:
        token = auth.entra_exchange(conf, code, flow["v"], public_url(request) + "/auth/entra/callback")
        email, name = auth.entra_claims(conf, token, flow["n"])
    except Exception as e:  # noqa: BLE001
        return fail(f"Connexion Microsoft impossible ({e})")
    role = os.environ.get("ENTRA_AUTO_CREATE_ROLE", "").strip()
    with db.connect() as con:
        u = auth.get_user(con, email)
        if u is None and role in db.ROLES:
            con.execute("INSERT INTO users(email, name, role, pw_hash, active, created) VALUES (?,?,?,?,1,?)",
                        (email, name, role, None, db.now()))
            u = auth.get_user(con, email)
    if u is None or not u["active"]:
        return fail("Ce compte n'a pas accès à VigiePatch, demande à un administrateur")
    resp = RedirectResponse("/")
    resp.delete_cookie(OIDC_COOKIE, path="/auth/entra")
    start_session(resp, request, email)
    return resp


# ---------- données ----------
@app.get("/api/state")
def state(u=Depends(any_user)):
    with db.connect() as con:
        parc = [dict(r) for r in con.execute("SELECT id, name, ver, n FROM products ORDER BY name")]
        events = {}
        for r in con.execute("SELECT key, who, what, t FROM events ORDER BY id"):
            events.setdefault(r["key"], []).append({"who": r["who"], "what": r["what"], "t": r["t"]})
        cves = []
        for r in con.execute("SELECT * FROM cves"):
            d = dict(r)
            d["kev"] = bool(d["kev"])
            d["h"] = events.get(d["key"], [])
            cves.append(d)
    return {"me": {"email": u["email"], "name": u["name"], "role": u["role"]}, "parc": parc, "cves": cves}


@app.post("/api/cves/{key}/claim")
def claim(key: str, u=Depends(can_write)):
    with db.connect() as con:
        cur = con.execute("UPDATE cves SET owner=?, status='pris' WHERE key=? AND status='nouveau'", (u["name"], key))
        if cur.rowcount == 0:
            row = con.execute("SELECT owner FROM cves WHERE key=?", (key,)).fetchone()
            if row is None:
                raise HTTPException(404, "CVE inconnue")
            who = row["owner"] or "quelqu'un"
            raise HTTPException(409, f"Déjà pris en compte par {who}")
        db.add_event(con, key, u["name"], "A pris en compte")
    return {"ok": True}


@app.post("/api/cves/{key}/status")
def set_status(key: str, body: StatusIn, u=Depends(can_write)):
    if body.status not in db.STATUSES:
        raise HTTPException(422, "Statut invalide")
    with db.connect() as con:
        row = con.execute("SELECT owner FROM cves WHERE key=?", (key,)).fetchone()
        if row is None:
            raise HTTPException(404, "CVE inconnue")
        owner = row["owner"] or (u["name"] if body.status != "nouveau" else "")
        con.execute("UPDATE cves SET status=?, owner=? WHERE key=?", (body.status, owner, key))
        db.add_event(con, key, u["name"], f"Statut : {body.status}")
    return {"ok": True}


@app.post("/api/cves/{key}/note")
def add_note(key: str, body: NoteIn, u=Depends(can_write)):
    text = body.text.strip()
    if not text:
        raise HTTPException(422, "Note vide")
    with db.connect() as con:
        if con.execute("SELECT 1 FROM cves WHERE key=?", (key,)).fetchone() is None:
            raise HTTPException(404, "CVE inconnue")
        db.add_event(con, key, u["name"], f"Note : {text}")
    return {"ok": True}


@app.post("/api/products")
def add_product(body: ProductIn, u=Depends(admin_only)):
    name, ver = body.name.strip(), body.ver.strip()
    pid = re.sub(r"[^a-z0-9]+", "-", f"{name} {ver}".lower()).strip("-")
    try:
        with db.connect() as con:
            con.execute("INSERT INTO products(id, name, ver, n) VALUES (?,?,?,?)", (pid, name, ver, body.n))
    except sqlite3.IntegrityError:
        raise HTTPException(409, "Ce produit est déjà dans le parc")
    path = db.DATA / "inventory.json"
    items = json.loads(path.read_text(encoding="utf-8")) if path.exists() else []
    items.append({"id": pid, "name": name, "ver": ver, "n": body.n, "keyword": f"{name} {ver}"})
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)
    return {"ok": True, "id": pid}


# ---------- administration des utilisateurs ----------
def check_password(pw):
    if pw is not None and len(pw) < 10:
        raise HTTPException(422, "Le mot de passe doit faire au moins 10 caractères")


def other_admins(con, email):
    return con.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1 AND email!=?", (email,)).fetchone()[0]


@app.get("/api/users")
def list_users(_=Depends(admin_only)):
    with db.connect() as con:
        rows = con.execute("SELECT email, name, role, active, pw_hash IS NOT NULL AS pw, last_login FROM users ORDER BY email")
        return [{"email": r["email"], "name": r["name"], "role": r["role"], "active": bool(r["active"]),
                 "has_password": bool(r["pw"]), "last_login": r["last_login"]} for r in rows]


@app.post("/api/users")
def create_user(body: UserIn, _=Depends(admin_only)):
    email = auth.norm_email(body.email)
    if not auth.EMAIL_RE.match(email):
        raise HTTPException(422, "Adresse email invalide")
    if body.role not in db.ROLES:
        raise HTTPException(422, "Rôle invalide")
    pw = body.password or None
    check_password(pw)
    try:
        with db.connect() as con:
            con.execute("INSERT INTO users(email, name, role, pw_hash, active, created) VALUES (?,?,?,?,1,?)",
                        (email, (body.name or "").strip() or auth.default_name(email), body.role,
                         auth.hash_password(pw) if pw else None, db.now()))
    except sqlite3.IntegrityError:
        raise HTTPException(409, "Cet utilisateur existe déjà")
    return {"ok": True}


@app.patch("/api/users/{email}")
def patch_user(email: str, body: UserPatch, me=Depends(admin_only)):
    email = auth.norm_email(email)
    if body.role is not None and body.role not in db.ROLES:
        raise HTTPException(422, "Rôle invalide")
    check_password(body.password or None)
    with db.connect() as con:
        u = auth.get_user(con, email)
        if u is None:
            raise HTTPException(404, "Utilisateur inconnu")
        role = body.role if body.role is not None else u["role"]
        active = int(body.active) if body.active is not None else u["active"]
        if u["role"] == "admin" and u["active"] and (role != "admin" or not active) and other_admins(con, email) == 0:
            raise HTTPException(409, "Il doit rester au moins un administrateur actif")
        name = (body.name or "").strip() or u["name"]
        pw = auth.hash_password(body.password) if body.password else u["pw_hash"]
        con.execute("UPDATE users SET name=?, role=?, active=?, pw_hash=? WHERE email=?", (name, role, active, pw, email))
    return {"ok": True}


@app.delete("/api/users/{email}")
def delete_user(email: str, me=Depends(admin_only)):
    email = auth.norm_email(email)
    if email == me["email"]:
        raise HTTPException(409, "Tu ne peux pas supprimer ton propre compte")
    with db.connect() as con:
        u = auth.get_user(con, email)
        if u is None:
            raise HTTPException(404, "Utilisateur inconnu")
        if u["role"] == "admin" and u["active"] and other_admins(con, email) == 0:
            raise HTTPException(409, "Il doit rester au moins un administrateur actif")
        con.execute("DELETE FROM users WHERE email=?", (email,))
    return {"ok": True}
