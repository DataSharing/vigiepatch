"""Importe inventory.json et cves.json dans SQLite et notifie les nouvelles CVE prioritaires.

Usage: python -m app.sync
Env:   VIGIEPATCH_WEBHOOK (URL), VIGIEPATCH_WEBHOOK_FORMAT = json (défaut, {"text": ...}) ou text (corps brut, ex. ntfy)
Le statut, le responsable et les notes ne sont jamais écrasés par une synchronisation.
"""
import json
import os
import urllib.request

from . import db


def notify(lines):
    url = os.environ.get("VIGIEPATCH_WEBHOOK")
    if not url or not lines:
        return
    msg = f"VigiePatch : {len(lines)} nouvelle(s) CVE prioritaire(s)\n" + "\n".join(lines[:15])
    if os.environ.get("VIGIEPATCH_WEBHOOK_FORMAT", "json") == "text":
        data, ctype = msg.encode(), "text/plain; charset=utf-8"
    else:
        data, ctype = json.dumps({"text": msg}).encode(), "application/json"
    try:
        req = urllib.request.Request(url, data=data, headers={"Content-Type": ctype})
        urllib.request.urlopen(req, timeout=15).close()
    except Exception as e:  # noqa: BLE001
        print(f"webhook en échec: {e}")


def main():
    inv = db.DATA / "inventory.json"
    cves_path = db.DATA / "cves.json"
    fresh = []
    with db.connect() as con:
        if inv.exists():
            for p in json.loads(inv.read_text(encoding="utf-8")):
                con.execute(
                    "INSERT INTO products(id, name, ver, n) VALUES (?,?,?,?) "
                    "ON CONFLICT(id) DO UPDATE SET name=excluded.name, ver=excluded.ver, n=excluded.n",
                    (p["id"], p["name"], p["ver"], p.get("n", 1)),
                )
        names = {r["id"]: f"{r['name']} {r['ver']}" for r in con.execute("SELECT id, name, ver FROM products")}
        if not cves_path.exists():
            print("cves.json absent: rien à importer")
            return
        for c in json.loads(cves_path.read_text(encoding="utf-8")).get("cves", []):
            key = c.get("key", c["id"])
            exists = con.execute("SELECT 1 FROM cves WHERE key=?", (key,)).fetchone()
            vals = (c["id"], c["p"], c["cvss"], c["epss"], int(c["kev"]), c["title"], c["fix"], c["pub"])
            if exists:
                con.execute(
                    "UPDATE cves SET cvss=?, epss=?, kev=?, title=?, fix=? WHERE key=?",
                    (c["cvss"], c["epss"], int(c["kev"]), c["title"], c["fix"], key),
                )
            else:
                con.execute(
                    "INSERT INTO cves(key, id, p, cvss, epss, kev, title, fix, pub) VALUES (?,?,?,?,?,?,?,?,?)",
                    (key,) + vals,
                )
                if c["kev"] or c["cvss"] >= 9:
                    tag = ", exploitée" if c["kev"] else ""
                    fresh.append(f"{c['id']} (CVSS {c['cvss']}{tag}) : {names.get(c['p'], c['p'])}")
    print(f"import terminé, {len(fresh)} nouvelle(s) prioritaire(s)")
    notify(fresh)


if __name__ == "__main__":
    main()
