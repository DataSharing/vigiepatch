"""Comptes, mots de passe, sessions signées et connexion Microsoft Entra (OpenID Connect)."""
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import time
import urllib.parse
import urllib.request

from . import db

SESSION_TTL = 12 * 3600
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
GUID_RE = re.compile(r"^[0-9a-f]{8}-([0-9a-f]{4}-){3}[0-9a-f]{12}$", re.I)


def b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def unb64(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


# ---------- mots de passe ----------
def hash_password(pw: str) -> str:
    salt = os.urandom(16)
    h = hashlib.scrypt(pw.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return f"scrypt${b64(salt)}${b64(h)}"


def verify_password(pw: str, stored) -> bool:
    if not stored:
        return False
    try:
        _, s, h = stored.split("$")
        got = hashlib.scrypt(pw.encode(), salt=unb64(s), n=2**14, r=8, p=1, dklen=32)
        return hmac.compare_digest(got, unb64(h))
    except Exception:  # noqa: BLE001
        return False


# ---------- sessions signées ----------
def _secret() -> bytes:
    s = os.environ.get("VIGIEPATCH_SECRET")
    if s:
        return s.encode()
    p = db.DATA / "secret.key"
    if not p.exists():
        db.DATA.mkdir(parents=True, exist_ok=True)
        fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(secrets.token_urlsafe(48))
    return p.read_text().strip().encode()


def sign(payload: dict, ttl: int) -> str:
    body = b64(json.dumps(dict(payload, x=int(time.time()) + ttl)).encode())
    return body + "." + b64(hmac.new(_secret(), body.encode(), hashlib.sha256).digest())


def unsign(token: str):
    try:
        body, mac = token.split(".")
        good = b64(hmac.new(_secret(), body.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(mac, good):
            return None
        data = json.loads(unb64(body))
        return data if data.get("x", 0) > time.time() else None
    except Exception:  # noqa: BLE001
        return None


# ---------- utilisateurs ----------
def norm_email(e: str) -> str:
    return e.strip().lower()


def default_name(email: str) -> str:
    return email.split("@")[0]


def get_user(con, email: str):
    return con.execute("SELECT * FROM users WHERE email=?", (norm_email(email),)).fetchone()


def ensure_admin():
    """Crée le premier administrateur quand la table est vide."""
    with db.connect() as con:
        if con.execute("SELECT COUNT(*) FROM users").fetchone()[0]:
            return
        email = norm_email(os.environ.get("VIGIEPATCH_ADMIN_EMAIL", "walid@gmail.com"))
        pw = os.environ.get("VIGIEPATCH_PASSWORD", "")
        con.execute(
            "INSERT INTO users(email, name, role, pw_hash, active, created) VALUES (?,?,?,?,1,?)",
            (email, default_name(email), "admin", hash_password(pw) if pw else None, db.now()),
        )


# ---------- limitation des tentatives ----------
_fails: dict = {}


def throttled(key: str) -> bool:
    n, until = _fails.get(key, (0, 0))
    return n >= 5 and until > time.time()


def record_fail(key: str):
    n, _ = _fails.get(key, (0, 0))
    _fails[key] = (n + 1, time.time() + 300)


def clear_fail(key: str):
    _fails.pop(key, None)


# ---------- Microsoft Entra (OIDC, code + PKCE) ----------
def entra_conf():
    t, c, s = (os.environ.get(k, "").strip() for k in ("ENTRA_TENANT_ID", "ENTRA_CLIENT_ID", "ENTRA_CLIENT_SECRET"))
    return {"tenant": t, "client": c, "secret": s} if t and c and s else None


def entra_authorize_url(conf, redirect_uri, state, nonce, challenge):
    q = urllib.parse.urlencode({
        "client_id": conf["client"], "response_type": "code", "redirect_uri": redirect_uri,
        "response_mode": "query", "scope": "openid profile email", "state": state, "nonce": nonce,
        "code_challenge": challenge, "code_challenge_method": "S256", "prompt": "select_account",
    })
    return f"https://login.microsoftonline.com/{conf['tenant']}/oauth2/v2.0/authorize?{q}"


def entra_exchange(conf, code, verifier, redirect_uri) -> str:
    """Échange le code contre un id_token (appel serveur à serveur en TLS)."""
    data = urllib.parse.urlencode({
        "grant_type": "authorization_code", "code": code, "redirect_uri": redirect_uri,
        "client_id": conf["client"], "client_secret": conf["secret"], "code_verifier": verifier,
        "scope": "openid profile email",
    }).encode()
    req = urllib.request.Request(
        f"https://login.microsoftonline.com/{conf['tenant']}/oauth2/v2.0/token", data=data,
        headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.load(r)["id_token"]


def entra_claims(conf, id_token, nonce):
    """Valide les claims. Le jeton vient directement du endpoint Microsoft en TLS (OIDC Core 3.1.3.7)."""
    claims = json.loads(unb64(id_token.split(".")[1]))
    tid = claims.get("tid", "")
    if claims.get("aud") != conf["client"]:
        raise ValueError("audience invalide")
    if claims.get("iss") != f"https://login.microsoftonline.com/{tid}/v2.0":
        raise ValueError("émetteur invalide")
    if GUID_RE.match(conf["tenant"]) and tid.lower() != conf["tenant"].lower():
        raise ValueError("tenant non autorisé")
    if not hmac.compare_digest(str(claims.get("nonce", "")), nonce):
        raise ValueError("nonce invalide")
    if claims.get("exp", 0) < time.time():
        raise ValueError("jeton expiré")
    email = claims.get("email") or claims.get("preferred_username") or claims.get("upn") or ""
    if not EMAIL_RE.match(email):
        raise ValueError("aucune adresse email dans le jeton")
    return norm_email(email), claims.get("name") or default_name(email)
