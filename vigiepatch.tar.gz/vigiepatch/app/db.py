import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

DATA = Path(os.environ.get("VIGIEPATCH_DATA", Path(__file__).resolve().parent.parent / "data"))
DB = DATA / "vigiepatch.db"
STATUSES = ("nouveau", "pris", "cours", "patche", "ignore")

SCHEMA = """
CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, ver TEXT NOT NULL, n INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS cves (
  key TEXT PRIMARY KEY, id TEXT NOT NULL, p TEXT NOT NULL,
  cvss REAL NOT NULL DEFAULT 0, epss INTEGER NOT NULL DEFAULT 0, kev INTEGER NOT NULL DEFAULT 0,
  title TEXT NOT NULL DEFAULT '', fix TEXT NOT NULL DEFAULT '', pub TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'nouveau', owner TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT NOT NULL, who TEXT NOT NULL,
  what TEXT NOT NULL, t TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS events_key ON events(key);
CREATE TABLE IF NOT EXISTS users (
  email TEXT PRIMARY KEY, name TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'consultation',
  pw_hash TEXT, active INTEGER NOT NULL DEFAULT 1, created TEXT NOT NULL, last_login TEXT
);
"""
ROLES = ("admin", "technicien", "consultation")


def now():
    return datetime.now(timezone.utc).isoformat()


@contextmanager
def connect():
    DATA.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB, timeout=15)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript(SCHEMA)
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


def add_event(con, key, who, what):
    con.execute("INSERT INTO events(key, who, what, t) VALUES (?,?,?,?)", (key, who, what, now()))
