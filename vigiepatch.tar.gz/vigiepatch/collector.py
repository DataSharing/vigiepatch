#!/usr/bin/env python3
"""VigiePatch collector: NVD + CISA KEV + EPSS -> cves.json, filtered on inventory.json.

Usage:  python3 collector.py [--days 30] [--inventory inventory.json] [--out cves.json]
Env:    NVD_API_KEY (optional, raises the NVD rate limit)
Stdlib only. Existing status/owner/history in --out are preserved on every run.
"""
import argparse, json, os, sys, time, urllib.parse, urllib.request
from datetime import datetime, timedelta, timezone

NVD = "https://services.nvd.nist.gov/rest/json/cves/2.0"
KEV = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
EPSS = "https://api.first.org/data/v1/epss"
UA = {"User-Agent": "vigiepatch-collector/0.1"}


def get_json(url, headers=None, retries=3):
    h = dict(UA, **(headers or {}))
    for i in range(retries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=60) as r:
                return json.load(r)
        except Exception as e:  # noqa: BLE001
            print(f"  retry {i + 1}/{retries}: {e}", file=sys.stderr)
            time.sleep(10 * (i + 1))
    raise SystemExit(f"échec: {url}")


def nvd_query(item, start, end, key):
    p = {"pubStartDate": start, "pubEndDate": end, "resultsPerPage": 200}
    if item.get("cpe"):
        p["virtualMatchString"] = item["cpe"]
    else:
        p["keywordSearch"] = item["keyword"]
    out, idx = [], 0
    while True:
        p["startIndex"] = idx
        data = get_json(NVD + "?" + urllib.parse.urlencode(p), {"apiKey": key} if key else None)
        out += data.get("vulnerabilities", [])
        idx += data.get("resultsPerPage", 0)
        if idx >= data.get("totalResults", 0) or not data.get("resultsPerPage"):
            return out
        time.sleep(1 if key else 6)  # limites NVD: 5 req/30 s sans clé


def cvss_of(cve):
    m = cve.get("metrics", {})
    for k in ("cvssMetricV31", "cvssMetricV40", "cvssMetricV30", "cvssMetricV2"):
        if m.get(k):
            return float(m[k][0]["cvssData"]["baseScore"])
    return 0.0


def title_of(cve):
    for d in cve.get("descriptions", []):
        if d.get("lang") == "en":
            return d["value"].split("\n")[0][:220]
    return cve["id"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=30)  # NVD: fenêtre max 120 jours
    ap.add_argument("--inventory", default="inventory.json")
    ap.add_argument("--out", default="cves.json")
    a = ap.parse_args()
    key = os.environ.get("NVD_API_KEY")

    inventory = json.load(open(a.inventory, encoding="utf-8"))
    old = {}
    if os.path.exists(a.out):
        old = {c["id"]: c for c in json.load(open(a.out, encoding="utf-8")).get("cves", [])}

    end = datetime.now(timezone.utc)
    start = end - timedelta(days=min(a.days, 120))
    fmt = lambda d: d.strftime("%Y-%m-%dT%H:%M:%S.000")

    print("KEV…")
    kev = {v["cveID"] for v in get_json(KEV)["vulnerabilities"]}

    found = {}
    for item in inventory:
        print(f"NVD {item['name']} {item['ver']}…")
        for v in nvd_query(item, fmt(start), fmt(end), key):
            c = v["cve"]
            found.setdefault(c["id"], {"cve": c, "products": set()})["products"].add(item["id"])
        time.sleep(1 if key else 6)

    ids = list(found)
    epss = {}
    for i in range(0, len(ids), 80):
        chunk = ",".join(ids[i:i + 80])
        for r in get_json(f"{EPSS}?cve={chunk}").get("data", []):
            epss[r["cve"]] = round(float(r["epss"]) * 100)

    cves = []
    for cid, f in found.items():
        c = f["cve"]
        for pid in sorted(f["products"]):
            rid = cid if len(f["products"]) == 1 else f"{cid}|{pid}"
            prev = old.get(rid, {})
            refs = c.get("references", [])
            cves.append({
                "id": cid, "key": rid, "p": pid,
                "cvss": cvss_of(c), "epss": epss.get(cid, 0), "kev": cid in kev,
                "title": title_of(c),
                "fix": refs[0]["url"] if refs else "Voir le bulletin éditeur",
                "pub": c.get("published", ""),
                "status": prev.get("status", "nouveau"),
                "owner": prev.get("owner", ""),
                "h": prev.get("h", []),
            })
    cves.sort(key=lambda x: (not x["kev"], -x["cvss"]))
    json.dump({"generated": end.isoformat(), "cves": cves}, open(a.out, "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    print(f"{len(cves)} CVE écrites dans {a.out} ({sum(c['kev'] for c in cves)} exploitées)")


if __name__ == "__main__":
    main()
